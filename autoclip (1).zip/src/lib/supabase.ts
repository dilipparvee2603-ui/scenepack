import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://gdbkmqxvactieiiujwrs.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImdkYmttcXh2YWN0aWVpaXVqd3JzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzY1NDk4ODQsImV4cCI6MjA5MjEyNTg4NH0.9D5PBgtLivFCQ0IoFG1DgK44Ik9aqwjrjQv_OZI9e_k';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
