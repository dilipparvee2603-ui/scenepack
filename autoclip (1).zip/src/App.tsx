import React, { useState, useRef } from "react";
import { UploadCloud, Play, Download, CheckCircle2, Circle, Loader2, ArrowLeft } from "lucide-react";
import { cn } from "./lib/utils";
import { supabase } from "./lib/supabase";

type AppState = "upload" | "uploading" | "preview" | "processing" | "clips" | "frames" | "downloadReady";
type AppModule = "scenes" | "frames";

type Clip = {
  index: number;
  start_time: string;
  end_time: string;
  start_timecode: string;
  end_timecode: string;
};

export default function App() {
  const [appState, setAppState] = useState<AppState>("upload");
  const [appModule, setAppModule] = useState<AppModule>("scenes");
  const [uploadProgress, setUploadProgress] = useState(0);
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [videoId, setVideoId] = useState<string | null>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [videoDuration, setVideoDuration] = useState<number>(0);
  
  const [detector, setDetector] = useState<"adaptive" | "content">("adaptive");
  const [adaptiveThreshold, setAdaptiveThreshold] = useState<number>(2.8);
  const [contentThreshold, setContentThreshold] = useState<number>(30);
  
  const [clips, setClips] = useState<Clip[]>([]);
  const [selectedClips, setSelectedClips] = useState<Set<number>>(new Set());
  const [downloadUrls, setDownloadUrls] = useState<{ url: string; label: string }[]>([]);
  const [activePreviewClip, setActivePreviewClip] = useState<Clip | null>(null);
  const [detectionMethod, setDetectionMethod] = useState<string | null>(null);
  
  const [frames, setFrames] = useState<string[]>([]);
  const [selectedFrames, setSelectedFrames] = useState<Set<string>>(new Set());
  const [extractFps, setExtractFps] = useState<number>(5);
  
  const [processingText, setProcessingText] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    setVideoFile(file);
    setAppState("uploading");
    setUploadProgress(0);

    try {
      // 1. Upload to Supabase Storage
      // Path: videos/[unique-id]-[name]
      const fileExt = file.name.split('.').pop();
      const fileName = `${Math.random().toString(36).substring(2, 12)}.${fileExt}`;
      const filePath = `videos/${fileName}`;

      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('videos')
        .upload(filePath, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (uploadError) throw uploadError;

      // 2. Get Public URL
      const { data: { publicUrl } } = supabase.storage
        .from('videos')
        .getPublicUrl(filePath);

      setUploadProgress(50); // Mark halfway as storage upload done

      // 3. Notify Backend to process the Supabase URL
      const resp = await fetch("/api/upload-supabase", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          url: publicUrl,
          fileName: file.name,
          id: fileName.split('.')[0]
        })
      });

      if (!resp.ok) {
        const errData = await resp.json();
        throw new Error(errData.details || errData.error || "Backend processing failed");
      }

      const response = await resp.json();
      setUploadProgress(100);
      setVideoId(response.id);
      setVideoUrl(`/uploads/${response.path}`);
      if (response.fps) {
        setExtractFps(response.fps);
      }
      setAppState("preview");

    } catch (err: any) {
      console.error("Supabase Upload Error:", err);
      alert(`Upload Failed: ${err.message || "Unknown error"}. Make sure you have created a public bucket named 'videos' in Supabase.`);
      setAppState("upload");
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024, sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const [clipThumbnails, setClipThumbnails] = useState<Record<number, string>>({});
  
  const generateThumbnail = (time: number): Promise<string> => {
    return new Promise((resolve) => {
      if (!videoRef.current) return resolve("");
      const video = document.createElement("video");
      video.src = videoRef.current.src;
      video.crossOrigin = "anonymous";
      video.currentTime = time;
      video.addEventListener("seeked", () => {
        const canvas = document.createElement("canvas");
        // Keep original aspect ratio width/height
        canvas.width = video.videoWidth || 320;
        canvas.height = video.videoHeight || 180;
        const ctx = canvas.getContext("2d");
        ctx?.drawImage(video, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL("image/jpeg", 0.5));
      }, { once: true });
    });
  };

  const handleDetectScenes = async () => {
    if (!videoId) return;
    
    setAppState("processing");
    setProcessingText("Analyzing video...");
    
    try {
      const threshold = detector === "adaptive" ? adaptiveThreshold : contentThreshold;
      const response = await fetch("/api/detect", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          id: videoId, 
          threshold,
          detector 
        })
      });
      
      const text = await response.text();
      let data;
      try {
        data = JSON.parse(text);
      } catch (e) {
        console.error("Detect response is not valid JSON:", text);
        throw new Error("Server returned an invalid response.");
      }

      if (!response.ok) throw new Error(data?.error || "Detection failed");
      
      const detectedClips = data.scenes || [];
      setDetectionMethod(data.method || null);
      
      setClips(detectedClips);
      // By default start with all clips deselected (empty set) per user request
      setSelectedClips(new Set());
      setAppState("clips");
      
      // Async generate thumbnails
      const thumbs: Record<number, string> = {};
      for (const clip of detectedClips) {
         thumbs[clip.index] = await generateThumbnail(parseFloat(clip.start_time) + 0.5);
         setClipThumbnails({ ...thumbs });
      }
    } catch (err: any) {
      console.error(err);
      alert("Scene detection failed: " + err.message);
      setAppState("preview");
    }
  };

  const handleExtractFrames = async () => {
    if (!videoId) return;
    
    setAppState("processing");
    setProcessingText(`Extracting frames at ${extractFps}fps...`);
    
    try {
      const response = await fetch("/api/frames/extract", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: videoId, fps: extractFps })
      });
      
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Extraction failed");
      
      setFrames(data.frames || []);
      setSelectedFrames(new Set());
      setAppState("frames");
    } catch (err: any) {
      console.error(err);
      alert("Frame extraction failed: " + err.message);
      setAppState("preview");
    }
  };

  const toggleFrameSelection = (frameUrl: string) => {
    const newSet = new Set(selectedFrames);
    if (newSet.has(frameUrl)) {
      newSet.delete(frameUrl);
    } else {
      newSet.add(frameUrl);
    }
    setSelectedFrames(newSet);
  };

  const handleExportFrames = async () => {
    if (selectedFrames.size === 0 || !videoId) return;
    
    // Instead of zipping, we'll provide the individual Frame URLs for download
    const frameUrls = Array.from(selectedFrames);
    const newDownloadUrls = frameUrls.map((url: string, index) => {
      const fileName = url.split('/').pop() || `frame_${index}.jpg`;
      return {
        url: url,
        label: `Download ${fileName}`
      };
    });
    
    setDownloadUrls(newDownloadUrls);
    setAppState("downloadReady");
  };

  const toggleClipSelection = (index: number) => {
    const newSet = new Set(selectedClips);
    if (newSet.has(index)) {
      newSet.delete(index);
    } else {
      newSet.add(index);
    }
    setSelectedClips(newSet);
  };

  const handleClipClick = (clip: Clip) => {
    setActivePreviewClip(clip);
    if (videoRef.current) {
      videoRef.current.currentTime = parseFloat(clip.start_time);
      videoRef.current.play().catch(() => {}); // Attempt auto-play
    }
    toggleClipSelection(clip.index);
  };

  const handleExportZip = async () => {
    if (selectedClips.size === 0 || !videoId) return;
    
    setAppState("processing");
    setProcessingText("Generating clips...");
    
    try {
      const clipsToProcess = clips.filter(c => selectedClips.has(c.index));
      
      // 1. Generate clips on backend
      const generateRes = await fetch("/api/clip", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: videoId, clips: clipsToProcess })
      });
      
      const text = await generateRes.text();
      let data;
      try {
        data = JSON.parse(text);
      } catch (e) {
        console.error("Clip zip response is not valid JSON:", text);
        throw new Error("Server returned an invalid HTML response.");
      }

      if (!generateRes.ok) throw new Error(data?.error || "Clip generation failed");
      const { results } = data;
      
      const url = `/api/download/zip?id=${videoId}&clips=${results.join(',')}`;
      setDownloadUrls([{url, label: "Download ZIP Archive"}]);
      setAppState("downloadReady");
      
    } catch (err) {
      console.error(err);
      alert("Failed to export ZIP.");
      setAppState("clips");
    }
  };

  const handleExportIndividual = async () => {
    if (selectedClips.size === 0 || !videoId) return;
    
    setAppState("processing");
    setProcessingText("Generating clips...");
    
    try {
      const clipsToProcess = clips.filter(c => selectedClips.has(c.index));
      
      // 1. Generate clips
      const generateRes = await fetch("/api/clip", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: videoId, clips: clipsToProcess })
      });
      
      const text = await generateRes.text();
      let data;
      try {
        data = JSON.parse(text);
      } catch (e) {
        console.error("Clip individual response is not valid JSON:", text);
        throw new Error("Server returned an invalid HTML response.");
      }

      if (!generateRes.ok) throw new Error(data?.error || "Clip generation failed");
      const { results } = data;
      
      const newUrls = results.map((r: string) => ({
        url: `/api/download/${r}`,
        label: `Download ${r}`
      }));
      setDownloadUrls(newUrls);
      setAppState("downloadReady");
      
    } catch (err) {
      console.error(err);
      alert("Failed to export clips.");
      setAppState("clips");
    }
  };

  const [downloading, setDownloading] = useState<string | null>(null);

  const triggerDownload = async (url: string, fileName: string) => {
    if (downloading) return;
    setDownloading(fileName);
    try {
      const resp = await fetch(url);
      if (!resp.ok) throw new Error(`Download failed: ${resp.status}`);
      
      const blob = await resp.blob();
      const blobUrl = window.URL.createObjectURL(blob);
      
      const link = document.createElement("a");
      link.href = blobUrl;
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      // Cleanup
      setTimeout(() => window.URL.revokeObjectURL(blobUrl), 100);
    } catch (err: any) {
      console.error("Download error:", err);
      alert(`Download failed: ${err.message}. Please check your connection or try again.`);
    } finally {
      setDownloading(null);
    }
  };

  return (
    <div className="min-h-screen bg-[#111] text-[#fafafa] flex justify-center w-full font-sans">
      <div className="w-full max-w-[480px] bg-[#09090b] flex flex-col relative pb-[100px] min-h-screen shadow-2xl">
        
        {/* Header */}
        <header className="h-16 px-5 flex items-center border-b border-[#27272a] bg-[#09090b]/80 backdrop-blur-[10px] z-10 sticky top-0 shrink-0">
          {appState !== "upload" && appState !== "uploading" ? (
             <button 
               onClick={() => {
                 if (appState === 'clips') setAppState('preview');
                 else if (appState === 'frames') setAppState('preview');
                 else if (appState === 'downloadReady') {
                    if (appModule === 'scenes') setAppState('clips');
                    else setAppState('frames');
                 }
                 else if (appState === 'preview') {
                    setAppState('upload');
                    setVideoFile(null);
                    setVideoUrl(null);
                    setVideoId(null);
                 }
               }}
               className="w-6 h-6 flex items-center text-[#a1a1aa] hover:text-[#fafafa] transition-colors"
                aria-label="Back"
             >
               <ArrowLeft className="w-5 h-5" strokeWidth={2.5} />
             </button>
          ) : <div className="w-6"></div>}
          <h1 className="text-[16px] font-semibold text-[#fafafa] m-0 flex-1 text-center uppercase tracking-wider">
            {appModule === "scenes" ? "Scene Detector" : "Frame Explorer"}
          </h1>
          <div className="w-6"></div>
        </header>

        <div className="p-4 flex flex-col gap-4">

        {/* --- UPLOAD STATE --- */}
        {appState === "upload" && (
          <div 
            className="flex flex-col items-center justify-center border border-[#27272a] rounded-[16px] p-8 bg-[#18181b] hover:border-[#6366f1] transition-colors cursor-pointer min-h-[240px]"
            onClick={() => fileInputRef.current?.click()}
          >
            <div className="w-16 h-16 rounded-full flex items-center justify-center mb-4">
               <UploadCloud className="w-10 h-10 text-[#6366f1]" />
            </div>
            <h2 className="text-[16px] font-semibold text-[#fafafa] mb-2">Tap to upload video</h2>
            <p className="text-[14px] text-[#a1a1aa] text-center max-w-[200px]">Any video format up to 500MB</p>
            <input 
              type="file" 
              className="hidden" 
              ref={fileInputRef}
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (!file) return;
                // Basic validation
                if (!file.type.includes('video') && !file.name.match(/\.(mp4|mov|avi|mkv|webm)$/i)) {
                   alert("Please select a valid video file.");
                   return;
                }
                handleFileSelect(e);
              }}
            />
          </div>
        )}

        {/* --- UPLOADING STATE --- */}
        {appState === "uploading" && (
          <div className="flex flex-col items-center justify-center p-6 bg-[#18181b] rounded-[16px] border border-[#27272a] min-h-[200px]">
            <h2 className="text-[16px] font-semibold text-[#fafafa] mb-6">
              Uploading... {uploadProgress}%
            </h2>
            
            <div className="w-full bg-[#27272a] h-1 rounded-full overflow-hidden mb-4 relative">
              <div 
                className="bg-[#6366f1] h-full transition-all duration-300 ease-out shadow-[0_0_10px_#6366f1]"
                style={{ width: `${uploadProgress}%` }}
              />
            </div>
            
            {videoFile && (
              <div className="flex flex-col items-center gap-1 w-full text-center">
                <p className="text-[14px] font-medium text-[#fafafa] truncate w-full px-4">{videoFile.name}</p>
                <p className="text-[14px] text-[#a1a1aa]">{formatFileSize(videoFile.size)}</p>
              </div>
            )}
          </div>
        )}

        {/* --- PREVIEW AND PROCESSING AND CLIPS COMMON HEADER (Player) --- */}
        {(appState === "preview" || appState === "processing" || appState === "clips" || appState === "frames") && videoUrl && (
          <div className="flex flex-col gap-4 animate-in fade-in zoom-in-95 duration-200">
            {appState === "preview" && (
               <div className="flex bg-[#18181b] p-1 rounded-xl border border-[#27272a] mb-2 shadow-inner">
                  <button 
                    onClick={() => setAppModule("scenes")} 
                    className={cn(
                      "flex-1 py-2 text-[12px] font-bold rounded-lg transition-all", 
                      appModule === "scenes" ? "bg-[#27272a] text-[#6366f1] shadow-lg" : "text-[#71717a] hover:text-[#fafafa]"
                    )}
                  >
                    SCENE DETECTOR
                  </button>
                  <button 
                    onClick={() => setAppModule("frames")} 
                    className={cn(
                      "flex-1 py-2 text-[12px] font-bold rounded-lg transition-all", 
                      appModule === "frames" ? "bg-[#27272a] text-[#6366f1] shadow-lg" : "text-[#71717a] hover:text-[#fafafa]"
                    )}
                  >
                    FRAME EXPLORER
                  </button>
               </div>
            )}

            <div className="w-full rounded-[20px] bg-[#000] relative flex items-center justify-center overflow-hidden border border-[#27272a] shadow-2xl">
              <video 
                 ref={videoRef}
                 src={videoUrl} 
                 className="w-full h-auto max-h-[70vh] block"
                 controls 
                 playsInline
                 onLoadedMetadata={(e) => setVideoDuration(e.currentTarget.duration)}
                 onTimeUpdate={(e) => {
                   if (activePreviewClip) {
                     // Subtract a small buffer (0.05s) to avoid stopping on the first frame of the next scene
                     const endTime = parseFloat(activePreviewClip.end_time) - 0.05;
                     if (e.currentTarget.currentTime >= endTime) {
                       e.currentTarget.pause();
                       setActivePreviewClip(null);
                     }
                   }
                 }}
              />
            </div>
            
            {appState === "preview" && appModule === "scenes" && (
              <div className="flex flex-col gap-4 animate-in slide-in-from-top-2 duration-300">
                <div className="bg-[#18181b] border border-[#27272a] rounded-[16px] p-4 flex flex-col gap-4">
                  <div className="flex items-center justify-between">
                    <span className="text-[14px] font-medium text-[#a1a1aa]">Detection Method</span>
                    <div className="flex bg-[#09090b] p-1 rounded-lg border border-[#27272a]">
                      <button
                        onClick={() => setDetector("adaptive")}
                        className={cn(
                          "px-3 py-1.5 text-[12px] font-medium rounded-md transition-all",
                          detector === "adaptive" ? "bg-[#6366f1] text-white" : "text-[#71717a] hover:text-[#fafafa]"
                        )}
                      >
                        Adaptive
                      </button>
                      <button
                        onClick={() => setDetector("content")}
                        className={cn(
                          "px-3 py-1.5 text-[12px] font-medium rounded-md transition-all",
                          detector === "content" ? "bg-[#6366f1] text-white" : "text-[#71717a] hover:text-[#fafafa]"
                        )}
                      >
                        Content
                      </button>
                    </div>
                  </div>

                  <div className="flex flex-col gap-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[14px] font-medium text-[#a1a1aa]">Sensitivity</span>
                      <span className="text-[14px] font-mono text-[#6366f1]">{detector === "adaptive" ? adaptiveThreshold : contentThreshold}</span>
                    </div>
                    <input 
                      type="range"
                      min={detector === "adaptive" ? "0.1" : "1"}
                      max={detector === "adaptive" ? "10.0" : "100"}
                      step={detector === "adaptive" ? "0.1" : "1"}
                      value={detector === "adaptive" ? adaptiveThreshold : contentThreshold}
                      onChange={(e) => {
                        const val = parseFloat(e.target.value);
                        if (detector === "adaptive") setAdaptiveThreshold(val);
                        else setContentThreshold(val);
                      }}
                      className="w-full h-1.5 bg-[#27272a] rounded-lg appearance-none cursor-pointer accent-[#6366f1]"
                    />
                    <div className="flex justify-between text-[10px] text-[#71717a] mt-1">
                      <span>{detector === "adaptive" ? "Less Cuts" : "Less Cuts"}</span>
                      <span>{detector === "adaptive" ? "More Cuts" : "More Cuts"}</span>
                    </div>
                  </div>
                </div>

                <button 
                  onClick={handleDetectScenes}
                  className="w-full h-12 bg-[#6366f1] text-[#fff] font-semibold text-[16px] rounded-[12px] shadow-[0_4px_12px_rgba(99,102,241,0.4)] active:scale-[0.98] transition-all flex items-center justify-center border-none cursor-pointer hover:bg-[#4f46e5]"
                >
                  <Play className="w-4 h-4 mr-2 fill-current" />
                  Detect Scenes
                </button>
              </div>
            )}

            {appState === "preview" && appModule === "frames" && (
              <div className="flex flex-col gap-4 animate-in slide-in-from-top-2 duration-300">
                 <div className="bg-[#18181b] border border-[#27272a] rounded-[16px] p-4 flex flex-col gap-4">
                    <div className="flex items-center justify-between">
                      <span className="text-[14px] font-medium text-[#a1a1aa]">Sampling Rate (FPS)</span>
                      <span className="text-[14px] font-mono text-[#6366f1]">{extractFps} fps</span>
                    </div>
                    <input 
                      type="range"
                      min="1"
                      max="60"
                      step="1"
                      value={extractFps}
                      onChange={(e) => setExtractFps(parseInt(e.target.value))}
                      className="w-full h-1.5 bg-[#27272a] rounded-lg appearance-none cursor-pointer accent-[#6366f1]"
                    />
                    <p className="text-[11px] text-[#71717a]">Lower FPS means less frames, higher FPS extracts more detail.</p>
                 </div>

                 <button 
                  onClick={handleExtractFrames}
                  className="w-full h-12 bg-[#6366f1] text-[#fff] font-semibold text-[16px] rounded-[12px] shadow-[0_4px_12px_rgba(99,102,241,0.4)] active:scale-[0.98] transition-all flex items-center justify-center border-none cursor-pointer hover:bg-[#4f46e5]"
                >
                  <UploadCloud className="w-4 h-4 mr-2" />
                  Extract All Frames
                </button>
              </div>
            )}
          </div>
        )}

        {/* --- PROCESSING OVERLAY/STATE --- */}
        {appState === "processing" && (
          <div className="flex flex-col items-center justify-center gap-4 py-12">
            <Loader2 className="w-10 h-10 text-[#6366f1] animate-spin" />
            <p className="text-[16px] font-medium text-[#a1a1aa]">{processingText}</p>
          </div>
        )}

        {/* --- DOWNLOAD READY STATE --- */}
        {appState === "downloadReady" && (
          <div className="flex flex-col items-center justify-center gap-6 py-12 animate-in fade-in slide-in-from-bottom-4">
            <div className="w-16 h-16 rounded-full bg-[#16a34a]/20 flex items-center justify-center mb-2">
               <CheckCircle2 className="w-10 h-10 text-[#16a34a]" />
            </div>
            
            <div className="text-center">
              <h2 className="text-[20px] font-bold text-[#fafafa] mb-2">Ready to save!</h2>
              <p className="text-[14px] text-[#a1a1aa] max-w-[280px]">Your files are ready to be downloaded.</p>
            </div>

            <div className="flex flex-col gap-3 w-full max-w-[320px] mt-4 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
              {downloadUrls.length > 1 && (
                <button 
                  onClick={async () => {
                    for (const link of downloadUrls) {
                      const fileName = link.url.split('/').pop() || "file";
                      await triggerDownload(link.url, fileName);
                      // Small delay to allow browser to handle multiple downloads
                      await new Promise(r => setTimeout(r, 300));
                    }
                  }}
                  disabled={!!downloading}
                  className="flex items-center justify-center gap-2 w-full h-[54px] bg-[#fafafa] text-[#09090b] rounded-[12px] font-bold text-[16px] transition-colors disabled:opacity-50 mb-2 sticky top-0 z-10 shadow-lg"
                >
                  <Download className="w-5 h-5" />
                  Save All Files
                </button>
              )}

              {downloadUrls.map((link, idx) => {
                const fileName = link.url.split('/').pop() || "file";
                const isDownloading = downloading === fileName;
                
                return (
                  <button 
                    key={idx}
                    onClick={() => triggerDownload(link.url, fileName)}
                    disabled={!!downloading}
                    className="flex items-center justify-center gap-2 w-full h-[54px] bg-[#6366f1] hover:bg-[#4f46e5] text-white rounded-[12px] font-semibold text-[16px] transition-colors disabled:opacity-50 shrink-0"
                  >
                    {isDownloading ? (
                      <Loader2 className="w-5 h-5 animate-spin" />
                    ) : (
                      <Download className="w-5 h-5" />
                    )}
                    {isDownloading ? "Downloading..." : link.label}
                  </button>
                );
              })}
            </div>
            
            <button
              onClick={() => {
                if (appModule === 'scenes') setAppState('clips');
                else setAppState('frames');
              }}
              className="mt-6 text-[#a1a1aa] hover:text-[#fafafa] text-[14px] underline underline-offset-4 transition-colors"
            >
              Back to {appModule === 'scenes' ? 'Clips' : 'Frames'}
            </button>
          </div>
        )}

        {/* --- CLIPS STATE --- */}
        {appState === "clips" && (
           <div className="flex flex-col gap-[12px] flex-1">
             <div className="text-[14px] font-semibold text-[#a1a1aa] uppercase tracking-[0.5px] mb-2 mt-4">
                Detected Clips ({clips.length})
             </div>
             
              <div className="grid grid-cols-2 gap-3 pb-4">
               {clips.map((clip) => {
                 const isSelected = selectedClips.has(clip.index);
                 
                 const startSec = parseFloat(clip.start_time);
                 const endSec = parseFloat(clip.end_time);
                 const dur = endSec - startSec;
                 
                 return (
                   <div 
                     key={clip.index}
                     onClick={() => handleClipClick(clip)}
                     className={cn(
                       "bg-[#18181b] rounded-[16px] border border-[#27272a] overflow-hidden flex flex-col transition-all cursor-pointer aspect-[4/5] active:scale-95",
                       !isSelected && "opacity-50 hover:opacity-80"
                     )}
                   >
                     <div className="w-full flex-1 bg-[#000] relative overflow-hidden flex items-center justify-center">
                        {clipThumbnails[clip.index] ? (
                            <img src={clipThumbnails[clip.index]} className="w-full h-full object-contain p-1" alt={`Clip ${clip.index}`} />
                        ) : (
                          <div className="w-full h-full bg-[#1c1c1f] animate-pulse"></div>
                        )}
                        
                        <div className="absolute top-2 left-2 bg-[#000]/60 px-1.5 py-0.5 rounded-[4px] text-[10px] text-[#fafafa] font-mono shadow-md backdrop-blur-sm z-10">
                          {clip.start_timecode.substring(3, 8)}
                        </div>
                     </div>

                     <div className="p-3 flex items-center justify-between border-t border-[#27272a]/50 bg-[#18181b] shrink-0">
                       <span className="text-[12px] font-medium font-mono text-[#fafafa] tabular-nums tracking-wide">
                         {clip.start_timecode.substring(3, 8)} – {clip.end_timecode.substring(3, 8)}
                       </span>
                       
                       <div className={cn(
                         "w-[20px] h-[20px] rounded-[6px] border-2 flex items-center justify-center transition-colors shrink-0",
                         isSelected 
                           ? "bg-[#6366f1] border-[#6366f1]" 
                           : "bg-transparent border-[#27272a]"
                       )}>
                         {isSelected && <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="4"><path d="M20 6L9 17l-5-5"/></svg>}
                       </div>
                     </div>
                   </div>
                 );
               })}
             </div>
           </div>
        )}

        {/* --- FRAMES STATE --- */}
        {appState === "frames" && (
           <div className="flex flex-col gap-4 flex-1">
             <div className="flex items-center justify-between mb-2 mt-4 px-2">
                <div className="text-[14px] font-semibold text-[#a1a1aa] uppercase tracking-[0.5px]">
                   Extracted Frames ({frames.length})
                </div>
                <button 
                  onClick={() => {
                    if (selectedFrames.size === frames.length) setSelectedFrames(new Set());
                    else setSelectedFrames(new Set(frames));
                  }}
                  className="text-[12px] text-[#6366f1] font-medium"
                >
                  {selectedFrames.size === frames.length ? "Deselect All" : "Select All"}
                </button>
             </div>

             <div className="grid grid-cols-3 gap-2 pb-10">
                {frames.map((url, i) => {
                  const isSelected = selectedFrames.has(url);
                  return (
                    <div 
                      key={i} 
                      onClick={() => toggleFrameSelection(url)} 
                      className={cn(
                        "relative aspect-video rounded-[12px] overflow-hidden border-2 cursor-pointer transition-all",
                        isSelected ? "border-[#6366f1] scale-[0.98]" : "border-[#27272a] opacity-70 hover:opacity-100"
                      )}
                    >
                      <img src={url} className="w-full h-full object-cover" loading="lazy" />
                      {isSelected && (
                        <div className="absolute inset-0 bg-[#6366f1]/20 flex items-center justify-center">
                           <div className="bg-[#6366f1] rounded-full p-1 shadow-lg animate-in zoom-in-50">
                              <CheckCircle2 className="w-5 h-5 text-white" strokeWidth={3} />
                           </div>
                        </div>
                      )}
                      <div className="absolute bottom-1 right-1 bg-black/50 px-1 rounded text-[8px] text-white font-mono uppercase tracking-[0.5px]">
                         FR-{i+1}
                      </div>
                    </div>
                  );
                })}
             </div>
           </div>
        )}
      </div></div>

      {/* --- BOTTOM ACTION BAR (Sticky) --- */}
      {appState === "clips" && (
        <div className="fixed bottom-0 left-0 right-0 max-w-[480px] mx-auto h-[80px] bg-[#111] border-t border-[#27272a] flex justify-center z-50 pt-3 pb-6 px-4 pb-safe shadow-[0_-10px_30px_rgba(0,0,0,0.5)]">
          <div className="w-full flex items-center justify-between">
            <div className="text-[14px] text-[#a1a1aa]">
               <span className="text-[#fafafa] font-medium">{selectedClips.size}</span> clips selected
            </div>
            
            <div className="flex items-center gap-2">
              {selectedClips.size > 1 && (
                <button 
                  onClick={handleExportIndividual}
                  className="h-[44px] px-3 bg-transparent border border-[#27272a] rounded-[10px] text-[#fafafa] text-[14px] hover:bg-[#18181b] transition-colors"
                >
                  Save MP4s
                </button>
              )}
              <button 
                onClick={selectedClips.size === 1 ? handleExportIndividual : handleExportZip}
                disabled={selectedClips.size === 0}
                className="h-[44px] px-5 bg-[#6366f1] rounded-[10px] text-[#fff] text-[14px] font-semibold flex items-center gap-2 active:scale-95 transition-transform disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Download className="w-4 h-4" />
                {selectedClips.size === 1 ? "Save Video" : "Save ZIP"}
              </button>
            </div>
          </div>
        </div>
      )}

      {appState === "frames" && (
        <div className="fixed bottom-0 left-0 right-0 max-w-[480px] mx-auto h-[80px] bg-[#111] border-t border-[#27272a] flex justify-center z-50 pt-3 pb-6 px-4 pb-safe shadow-[0_-10px_30px_rgba(0,0,0,0.5)]">
           <div className="w-full flex items-center justify-between">
            <div className="text-[14px] text-[#a1a1aa]">
               <span className="text-[#fafafa] font-medium">{selectedFrames.size}</span> frames selected
            </div>
            
            <button 
              onClick={handleExportFrames}
              disabled={selectedFrames.size === 0}
              className="h-[44px] px-5 bg-[#6366f1] rounded-[10px] text-[#fff] text-[14px] font-semibold flex items-center gap-2 active:scale-95 transition-transform disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Download className="w-4 h-4" />
              Save Selected JPGs
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

